var1 =  25
var2 = 6

# Add two numbers
sum = var1 + var2

# Display the sum
print( sum)
